<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="untitled_zh_CN">
<context>
    <name>Widget</name>
    <message>
        <location filename="widget.ui" line="14"/>
        <source>Client</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="widget.ui" line="255"/>
        <source>连接</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="widget.ui" line="32"/>
        <source>发送</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="widget.ui" line="223"/>
        <source>端口号:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="widget.ui" line="182"/>
        <source>连接服务器IP：</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="widget.ui" line="50"/>
        <source>Client客户端界面</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="widget.ui" line="94"/>
        <source>接收服务器信息：</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="widget.ui" line="121"/>
        <source>输入要发送至服务器信息：</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="widget.ui" line="134"/>
        <source>状态及输出：</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="widget.ui" line="150"/>
        <source>断开连接</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="widget.ui" line="166"/>
        <source>关闭</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="widget.ui" line="287"/>
        <source>用户名：</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
