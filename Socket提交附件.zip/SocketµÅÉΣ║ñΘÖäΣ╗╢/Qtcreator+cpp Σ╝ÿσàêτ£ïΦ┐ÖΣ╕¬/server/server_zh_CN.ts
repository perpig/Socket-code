<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="server_zh_CN">
<context>
    <name>server</name>
    <message>
        <location filename="server.ui" line="14"/>
        <source>server</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="server.ui" line="38"/>
        <source>Server服务器端界面</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="server.ui" line="51"/>
        <source>输入发送信息：</source>
        <oldsource>输入广播发送信息：</oldsource>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="server.ui" line="64"/>
        <source>接受到信息：</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="server.ui" line="81"/>
        <source>广播</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="server.ui" line="112"/>
        <source>关闭服务器</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="server.ui" line="139"/>
        <source>状态及输出：</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="server.ui" line="166"/>
        <source>目前连接情况：</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="server.ui" line="209"/>
        <source>本服务器IP：</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="server.ui" line="250"/>
        <source>端口号：</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="server.ui" line="288"/>
        <source>开始监听</source>
        <oldsource>创建服务器</oldsource>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="server.ui" line="321"/>
        <source>私发用户名：</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="server.ui" line="338"/>
        <source>私发</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
