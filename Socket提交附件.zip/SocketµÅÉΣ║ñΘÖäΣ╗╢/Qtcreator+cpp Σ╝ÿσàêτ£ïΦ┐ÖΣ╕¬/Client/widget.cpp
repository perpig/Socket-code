#include "widget.h"
#include "./ui_widget.h"

Widget::Widget(QWidget *parent)
    : QWidget(parent), ui(new Ui::Widget), socket(new QTcpSocket) // 创建初始化Socket对象
{
    ui->setupUi(this);

    connect(ui->cancleButton, &QPushButton::clicked, this, &Widget::close);

    connect(socket, &QTcpSocket::readyRead, this, &Widget::onServerDataReceived);
}

Widget::~Widget()
{
    delete ui;
    delete socket;
}

void Widget::on_connectButton_clicked()
// 连接按钮
{

    // 每次重新连接前断开之前的连接，防止多次绑定然后发很多次消息
    disconnect(socket, &QTcpSocket::connected, this, nullptr);
    disconnect(socket, &QTcpSocket::disconnected, this, nullptr);

    // 获取lienedit 的ip和port
    QString port = ui->cmdLinePortEdit->text();
    QString ip = ui->cmdLineServerIPEdit->text();

    // 函数原型[virtual] void QAbstractSocket::connectToHost(const QHostAddress &address, quint16 port, QIODevice::OpenMode openMode = ReadWrite)
    socket->connectToHost(QHostAddress(ip), port.toShort());

    // 连接服务器之后发出 connected 的信号
    connect(socket, &QTcpSocket::connected, this, [this]()
            {
                ui->showSituation->append("连接成功！");

                // 获取用户名
                QString username = ui->IDcmdLineEdit->text(); // 添加用户名输入框
                socket->write(username.toUtf8());             // 发送用户名
            },
            Qt::UniqueConnection);

    // 连接断开之后发出 disconnected 的信号
    connect(socket, &QTcpSocket::disconnected, this, [this]()
            { ui->showSituation->append("断开连接！"); }, Qt::UniqueConnection);
}

void Widget::on_sendButton_clicked()
// 发送给服务器按钮
{
    // 获取文本框内容
    QString originalText = ui->cmdLineSendServerEdit->toPlainText();

    //把发送文本格式化为<msg:普通消息内容>
    QString sendText = "<msg:"+ originalText + ">";
    qint64 bytes = socket->write(sendText.toUtf8()); // 使用 UTF-8 编码发送数据

    if (bytes < 0)
    {
        ui->showSituation->append("发送失败！");
    }
    else
    {
        // 每次重新连接前断开之前的连接，防止多次绑定然后发很多次消息
        disconnect(socket, &QTcpSocket::bytesWritten, this, nullptr);
        // 连接 bytesWritten 信号，当数据成功写入时触发
        connect(socket, &QTcpSocket::bytesWritten, this, [this, originalText](qint64)
                {
                    ui->showSituation->append("发送至服务器成功:" + originalText);
                    ui->cmdLineSendServerEdit->clear(); // 清空输入框
                });
    }
}


void Widget::on_privateSendButton_clicked()
//私发给用户
{
    //获取User名
    QString sendUser = ui->sendUserEdit->text();

    // 获取文本框内容
    QString originalText = ui->cmdLineSendServerEdit->toPlainText();

    //把发送文本格式化:<priv:目标用户名:消息内容>
    QString sendText = "<priv:" + sendUser + ":" + originalText + ">";
    qint64 bytes = socket->write(sendText.toUtf8()); // 使用 UTF-8 编码发送数据

    if (bytes < 0)
    {
        ui->showSituation->append("发送失败！");
    }
    else
    {
        // 每次重新连接前断开之前的连接，防止多次绑定然后发很多次消息
        disconnect(socket, &QTcpSocket::bytesWritten, this, nullptr);
        // 连接 bytesWritten 信号，当数据成功写入时触发
        connect(socket, &QTcpSocket::bytesWritten, this, [this, originalText, sendUser](qint64)
                {
                    ui->showSituation->append("私发信息发送成功至服务器:" + originalText);
                    ui->cmdLineSendServerEdit->clear(); // 清空输入框
                });
    }

}


void Widget::on_CloseButton_clicked()
// 关闭处理
{
    // 每次重新连接前断开之前的连接，防止多次绑定然后发很多次消息
    disconnect(socket, &QTcpSocket::disconnected, this, nullptr);
    // 连接断开后显示断开信息
    connect(socket, &QTcpSocket::disconnected, this, [this]()
            { ui->showSituation->append("断开连接！"); });

    // 关闭 socket 连接
    socket->close();
}

void Widget::onServerDataReceived()
// 处理服务器发送数据的槽函数
{
    // 从服务器读取所有可用的数据
    // 原来的 C++ socket 代码使用了 recv() 来接收数据，在 Qt 中用readAll()就够了
    QByteArray serverData = socket->readAll();
    QString message = QString::fromUtf8(serverData);

    // 根据消息类型显示不同内容
        if (message.startsWith("<msg:"))
        //服务器普通消息：
        {
            QString text = message.mid(5, message.length() - 6); // 提取普通消息内容
            // 将数据追加到 QTextBrowser 中
            ui->showRevServer->append("[server]:" + text);
            // 更新状态
            ui->showSituation->append("接受到服务器发送的数据.");
        }
        else if (message.startsWith("<priv:"))
        //用户私发消息
        {
            int secondColonIndex = message.indexOf(':', 6);
            QString sender = message.mid(6, secondColonIndex - 6); // 提取发送者用户名
            QString text = message.mid(secondColonIndex + 1, message.length() - secondColonIndex - 2); // 提取私聊消息内容
            // 将数据追加到 QTextBrowser 中
            ui->showRevServer->append("[client:" + sender + "]:" + text);
            // 更新状态
            ui->showSituation->append("接受到客户端" + sender + "发送的数据.");
        }
        else
        {
            // 更新状态
            ui->showSituation->append("接受到服务器数据格式有误:" + message);
        }

}

